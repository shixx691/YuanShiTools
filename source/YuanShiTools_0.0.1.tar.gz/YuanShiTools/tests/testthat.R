library(testthat)
library(YuanShiTools)

test_check("YuanShiTools")
